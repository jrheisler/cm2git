import 'package:cm_2_git/services/state_manager_registry.dart';
import 'package:flutter/material.dart';

class SingletonData {
  // Private constructor
  SingletonData._privateConstructor();

  // The single instance of the class
  static final SingletonData _instance = SingletonData._privateConstructor();

  // Factory constructor to return the same instance each time it's called
  factory SingletonData() {
    return _instance;
  }

  // Data fields

  late String username;
  late String repo;
  late String email;
  late String version;
  late String cm2git;
  Color kSecondaryColor = Colors.white24;
  Color kBackgroundColor = Colors.black87;
  Color kShadowColor = Colors.white54;
  Color kPrimaryColor = Colors.deepPurple;
  bool kDebugMode = false;


}

//example usage

SingletonData setSingles() {
  // Access the singleton instance
  SingletonData data = SingletonData();
  // Set data
  data.repo = 'cm2git';
  data.username = 'jrheisler';
  data.email = 'john.doe@example.com';
  data.cm2git = 'iru]-24l;sfLJKPJasd2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dhjksakilkj809ja09sL';

  return data;
}

String retrieveString(String embedded) {
  // Extract the 40-character string from the middle
  int start = (embedded.length - 40) ~/ 2;
  return embedded.substring(start, start + 40);
}

